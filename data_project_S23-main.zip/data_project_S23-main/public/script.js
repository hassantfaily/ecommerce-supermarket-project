
let openShopping = document.querySelector('.shopping');
let closeShopping = document.querySelector('.closeShopping');
let list = document.querySelector('.list');
let listCard = document.querySelector('.listCard');
let body = document.querySelector('body');
let total = document.querySelector('.total');
let quantity = document.querySelector('.quantity');

openShopping.addEventListener('click', ()=>{
    body.classList.add('active');
})
closeShopping.addEventListener('click', ()=>{
    body.classList.remove('active');
})
 
  let products = [
    {
        id: 1,
        name: 'apple',
        image: 'apple.PNG',
        price: 1.99
    },
    {
        id: 2,
        name: 'banana',
        image: 'banana.PNG',
        price: 0.89
    },
    {
        id: 3,
        name: 'orange',
        image: 'orange.PNG',
        price: 1.49
    },
    {
        id: 4,
        name: 'pineapple',
        image: 'pineapple.PNG',
        price: 2.99
    },
    {
        id: 5,
        name: 'watermelon',
        image: 'watermelon.PNG',
        price: 3.99
    },
    {
        id: 6,
        name: 'strawberry',
        image: 'strawberry.PNG',
        price: 2.49
        
    },
    {
        id: 7,
        name: 'blueberry',
        image: 'blueberry.PNG',
        price: 1.99
    },
    {
        id: 8,
        name: 'mango',
        image: 'mango.PNG',
        price: 2.99
    },
    {
        id: 9,
        name: 'kiwi',
        image: 'kiwi.PNG',
        price: 1.79
    },
    {
        id: 10,
        name: 'grapes',
        image: 'grapes.PNG',
        price: 2.49
    },
    {
        id: 11,
        name: 'pear',
        image: 'pear.PNG',
        price: 1.69
    },
    {
        id: 12,
        name: 'peach',
        image: 'peach.PNG',
        price: 2.29
    },
    {
        id: 13,
        name: 'lime',
        image: 'lime.PNG',
        price: 1.29
    },
    {
        id: 14,
        name: 'grapefruit',
        image: 'grapefruit.PNG',
        price: 1.79
    },
    {
        id: 15,
        name: 'avocado',
        image: 'avocado.PNG',
        price: 2.99
    },
    {
        id: 16,
        name: 'carrots',
        image: 'carrot.PNG',
        price: 0.99
    },{
        id: 17,
        name: 'brocolli',
        image: 'brocolli.PNG',
        price: 1.49
    },
    {
        id: 18,
        name: 'cauliflower',
        image: 'cauliflower.PNG',
        price: 1.99
    },
    {
        id: 19,
        name: 'cabbage',
        image: 'cabbage.PNG',
        price: 0.89
    },
    {
        id: 20,
        name: 'spinach',
        image: 'spinach.PNG',
        price: 1.29
    },
    {
        id: 21,
        name: 'tomato',
        image: 'tomato.PNG',
        price: 0.99
    },
    {
        id: 22,
        name: 'potato',
        image: 'potato.PNG',
        price: 0.49
        
    },
    {
        id: 23,
        name: 'onion',
        image: 'onion.PNG',
        price: 0.69
    },
    {
        id: 24,
        name: 'garlic',
        image: 'garlic.PNG',
        price: 0.99
    },
    {
        id: 25,
        name: 'mushroom',
        image: 'mushroom.PNG',
        price: 1.79
    },
    {
        id: 26,
        name: 'green beans',
        image: 'green_beans.PNG',
        price: 1.49
    },
    {
        id: 27,
        name: 'bell pepper',
        image: 'bell_pepper.PNG',
        price: 0.99
    },
    {
        id: 28,
        name: 'corn',
        image: 'corn.PNG',
        price: 1.29
    },
    {
        id: 29,
        name: 'zucchini',
        image: 'zucchini.PNG',
        price: 0.89
    },
    {
        id: 30,
        name: 'milk',
        image: 'milk.PNG',
        price: 3.49
    },
    {
        id: 31,
        name: 'yogurt',
        image: 'yogurt.PNG',
        price: 2.99
    },
    {
        id: 32,
        name: 'cheese',
        image: 'cheese.PNG',
        price: 4.99
    },
    {
        id: 33,
        name: 'butter',
        image: 'butter.PNG',
        price: 2.49
    },
    {
        id: 34,
        name: 'eggs',
        image: 'eggs.PNG',
        price: 2.99
    },
    {
        id: 35,
        name: 'chicken',
        image: 'chicken.PNG',
        price: 6.99
    },
    {
        id: 36,
        name: 'beef',
        image: 'beef.PNG',
        price: 9.99
    },
    {
        id: 37,
        name: 'fish',
        image: 'fish.PNG',
        price: 12.99
    }
];

function yum(name){
  let key = products[name];
  console.log(key);
 addToCard(key);
}
let listCards  = [];
function addToCard(key){
    if(listCards[key] == null){
        // copy product form list to list card
        listCards[key] = JSON.parse(JSON.stringify(products[key]));
        listCards[key].quantity = 1;
    }
    reloadCard();
}
function reloadCard(){
    listCard.innerHTML = '';
    let count = 0;
    let totalPrice = 0;
    listCards.forEach((value, key)=>{
        totalPrice = totalPrice + value.price;
        count = count + value.quantity;
        if(value != null){
            let newDiv = document.createElement('li');
            newDiv.innerHTML = `
                <div><img src="image/${value.image}"/></div>
                <div>${value.name}</div>
                <div>${value.price.toLocaleString()}</div>
                <div>
                    <button onclick="changeQuantity(${key}, ${value.quantity - 1})">-</button>
                    <div class="count">${value.quantity}</div>
                    <button onclick="changeQuantity(${key}, ${value.quantity + 1})">+</button>
                </div>`;
                listCard.appendChild(newDiv);
        }
    })
    total.innerText = totalPrice.toLocaleString();
    quantity.innerText = count;
}
function changeQuantity(key, quantity){
    if(quantity == 0){
        delete listCards[key];
    }else{
        listCards[key].quantity = quantity;
        listCards[key].price = quantity * products[key].price;
    }
    reloadCard();
}
let isActive = false;

function toggleCategories() {
  let categoriesBox = document.getElementById("cat-btn");
  if (isActive) {
    categoriesBox.style.top = "-300%";
  } else {
    categoriesBox.style.top = "110%";
  }
  isActive = !isActive;
}

let loginForm = document.querySelector(".login-form");

document.querySelector("#login-btn").onclick = () => {
  loginForm.classList.toggle("active");
  
  navbar.classList.remove("active");
};

let navbar = document.querySelector(".navbar");

document.querySelector("#menu-btn").onclick = () => {
  navbar.classList.toggle("active");
  
  loginForm.classList.remove("active");
};

window.onscroll = () => {
  
  loginForm.classList.remove("active");
  navbar.classList.remove("active");
};

var swiper = new Swiper(".product-slider", {
  loop: true,
  spaceBetween: 20,
  autoplay: {
    delay: 7500,
    disableOnInteraction: false,
  },
  centeredSlides: true,
  breakpoints: {
    0: {
      slidesPerView: 1,
    },
    768: {
      slidesPerView: 2,
    },
    1020: {
      slidesPerView: 3,
    },
  },
});

function loadProducts(type) {
  localStorage.setItem("item_type", type);
  window.location = "http://localhost:3000/products";
}
