# data_project_S23
## Usage
To use this application:
1. Clone this repository on your machine
2. Change directory to the project file 
3. Run the command below 
```javascript
npm run server
```

